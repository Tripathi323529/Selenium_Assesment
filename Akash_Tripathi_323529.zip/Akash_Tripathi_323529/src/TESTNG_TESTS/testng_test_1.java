package TESTNG_TESTS;

import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import BASE_CLASSES.Home_Page;
import BASE_CLASSES.Product_Detail_Page;
import BASE_CLASSES.Search_Results_Page;
import UTILITIES.excel_io;
import UTILITIES.product;

public class testng_test_1 {
	int i = -1;
	WebDriver dr;
	Logger log;
	Home_Page homepage;
	Search_Results_Page searchpage;
	Product_Detail_Page productpage;
	ArrayList<product> al;
	excel_io obj;
  @BeforeClass
  public void launch_browser() {
	  System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
	  dr = new ChromeDriver();
	  dr.get("http://examples.codecharge.com/Store/Default.php");
	  log = Logger.getLogger("devpinoyLogger");
	  al = new ArrayList<product>();
	  obj = new excel_io();
	  al.add(obj.read_excel_1(2, "Sheet1"));
	  al.add(obj.read_excel_1(3, "Sheet1"));
  }
  @Test (priority=-1)
  public void verify_homepage_title()
  {
	  homepage = new Home_Page(dr,log);
	  String exp_title = "Online Bookstore";
	  String act_title = homepage.return_title();
	  if(act_title.compareTo(exp_title)!=0)
		  homepage.create_log("verify_homepage_title", exp_title, act_title, "FAIL");
	  Assert.assertEquals(act_title, exp_title);
	  homepage.create_log("verify_homepage_title", exp_title, act_title, "PASS");
  }
  @Test (priority=1)
  public void verify_txt()
  {
	  String exp_txt = "Search Products";
	  String act_txt = homepage.return_txt();
	  if(act_txt.compareTo(exp_txt)!=0)
		  homepage.create_log("verify_txt", exp_txt, act_txt, "FAIL");
	  Assert.assertEquals(act_txt, exp_txt);
	  homepage.create_log("verify_txt", exp_txt, act_txt, "PASS");
  }
  @Test (priority=2, dependsOnMethods = "verify_txt")
  public void search_product()
  {
	  i++;
	  String exp_res = "Clicked Search";
	  String act_res = homepage.input_data(al.get(i).getCategory(), al.get(i).getSearch_str());
	  if(act_res.compareTo(exp_res)!=0)
		  homepage.create_log("search_product", exp_res, act_res, "FAIL");
	  Assert.assertEquals(act_res, exp_res);
	  homepage.create_log("search_product", exp_res, act_res, "PASS");
  }
  @Test (priority=3, dependsOnMethods = "search_product")
  public void verify_searchpage_title()
  {
	  searchpage = new Search_Results_Page(dr,log);
	  String exp_title = "SearchResults";
	  String act_title=searchpage.return_title();
	  if(act_title.compareTo(exp_title)!=0)
		  searchpage.create_log("verify_searchpage_title", exp_title, act_title, "FAIL");
	  Assert.assertEquals(exp_title, act_title);
	  searchpage.create_log("verify_searchpage_title", exp_title, act_title, "PASS");
  }
  @Test (priority=4, dependsOnMethods = "verify_searchpage_title")
  public void click_product()
  {
	  String exp_res="Clicked Product";
	  String act_res=searchpage.click_product();
	  if(act_res.compareTo(exp_res)!=0)
		  searchpage.create_log("click_product", exp_res, act_res, "FAIL");
	  Assert.assertEquals(act_res, exp_res);
	  searchpage.create_log("click_product", exp_res, act_res, "PASS");
  }
  @Test (priority=5, dependsOnMethods = "click_product")
  public void enter_quantity()
  {
	  productpage = new Product_Detail_Page(dr,log);
	  String exp_res = "Quantity Entered";
	  String act_res= productpage.input_qty(al.get(i).getQuantity());
	  if(act_res.compareTo(exp_res)!=0)
		  productpage.create_log("enter_quantity", exp_res, act_res, "FAIL");
	  Assert.assertEquals(act_res, exp_res);
	  productpage.create_log("enter_quantity", exp_res, act_res, "PASS");
  }
  @Test(priority=6, dependsOnMethods = "enter_quantity")
  public void click_add_btn()
  {
	  String exp_res="Button Clicked";
	  String act_res = productpage.click_btn();
	  if(act_res.compareTo(exp_res)!=0)
		  productpage.create_log("click_add_btn", exp_res, act_res, "FAIL");
	  Assert.assertEquals(act_res, exp_res);
	  productpage.create_log("click_add_btn", exp_res, act_res, "PASS");
  }
}

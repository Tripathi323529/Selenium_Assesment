package TESTNG_TESTS;

import java.util.ArrayList;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import BASE_CLASSES.Shopping_Cart;
import UTILITIES.expected_products;

public class testng_test_2 extends testng_test_1 {
	Shopping_Cart shoppingcart;
	ArrayList<expected_products> exp_data;
	@Test (priority = 7)
	public void get_data()
	{
		exp_data = new ArrayList<expected_products>();
		exp_data.add(obj.read_excel_2(2,"Sheet2"));
		exp_data.add(obj.read_excel_2(3,"Sheet2"));
	}
  @Test(priority=8, dependsOnMethods="click_add_btn")
  public void go_to_home() {
	  shoppingcart = new Shopping_Cart(dr,log);
	  String exp_res = "Link Clicked";
	  String act_res = shoppingcart.homepage();
	  if(act_res.compareTo(exp_res)!=0)
		  shoppingcart.create_log("go_to_home", exp_res, act_res, "FAIL");
	  Assert.assertEquals(exp_res, act_res);
	  shoppingcart.create_log("go_to_home", exp_res, act_res, "PASS");
  }
  @Test(priority=9, dependsOnMethods = "go_to_home")
  public void add_product()
  {
	  search_product();
	  click_product();
	  enter_quantity();
	  click_add_btn();
  }
  @Test(priority=10, dependsOnMethods="add_product", dataProvider = "expected product names")
  public void verify_prod_names(String exp_name)
  {
	  String act_name = shoppingcart.return_name();
	  if(act_name.compareTo(exp_name)!=0)
		  shoppingcart.create_log("verify_prod_names", exp_name, act_name, "FAIL");
	  Assert.assertEquals(exp_name, act_name);
	  shoppingcart.create_log("verify_prod_names", exp_name, act_name, "PASS");
  }
  @Test(priority=11, dependsOnMethods="add_product", dataProvider = "expected product totals")
  public void verify_prod_totals(String exp_total)
  {
	  String act_total = shoppingcart.return_total();
	  if(act_total.compareTo(exp_total)!=0)
		  shoppingcart.create_log("verify_prod_names", exp_total, act_total, "FAIL");
	  Assert.assertEquals(exp_total, act_total);
	  shoppingcart.create_log("verify_prod_names", exp_total, act_total, "PASS");
  }
  @DataProvider (name="expected product names")
  public String[] exp_prod_name()
  {
	  String[] str = new String[2];
	  str[0] = exp_data.get(0).getProduct_name();
	  str[1] = exp_data.get(1).getProduct_name();
	  return str;
  }
  @DataProvider (name="expected product totals")
  public String[] exp_prod_total()
  {
	  String[] str = new String[2];
	  str[0] = String.valueOf(exp_data.get(0).getTotal());
	  str[1] = String.valueOf(exp_data.get(1).getTotal());
	  return str;
  }
}
